Action()
{

	lr_start_transaction("1_LaunchUrl");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("Nop.customer=890053df-c0c4-4f40-b034-aa365e3810ea; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("ARRAffinity=f4edb6097d47b618727013498965259efd35f8883f487e535625e82c6dc8570c; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("ARRAffinitySameSite=f4edb6097d47b618727013498965259efd35f8883f487e535625e82c6dc8570c; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utma=78382081.160850164.1790913650.1790913650.1790913650.1; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmc=78382081; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmz=78382081.1790913650.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmt=1; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmb=78382081.1.10.1790913650; DOMAIN=demowebshop.tricentis.com");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_add_cookie("__RequestVerificationToken=fnJ1aUUAlLxaT2KY1240ldQKEA0ogAjJCH-cICAXMetkkns-_T8CeUYUBRFlm9q4u_iFSjC8y8FBj4_dC0-wAH6rvvl70U_9_VDxW1btBrk1; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmb=78382081.2.10.1790913650; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmb=78382081.4.10.1790913650; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmb=78382081.6.10.1790913650; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmb=78382081.7.10.1790913650; DOMAIN=demowebshop.tricentis.com");

/*Correlation comment - Do not change!  Original value='computers' Name ='C_category' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=C_category",
		"RegExp=a\\ href=\"/(.*?)\">\\\r",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/demowebshop.tricentis.com/*",
		LAST);

	web_url("demowebshop.tricentis.com", 
		"URL=https://demowebshop.tricentis.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/Themes/DefaultClean/Content/images/bullet-right.gif", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/star-x-inactive.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/loading.gif", "Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/top-menu-divider.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		"Url=/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/bullets.png", "Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", ENDITEM, 
		"Url=/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/arrows.png", "Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/top-menu-triangle.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/top-menu-list-image.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/top-menu-list-image-hover.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/ico-arrow-r.gif", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/ajax_loader_large.gif", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/ajax_loader_small.gif", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/arrow-up.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		LAST);

	lr_end_transaction("1_LaunchUrl",LR_AUTO);

	lr_start_transaction("2_Register");

	web_url("Register", 
		"URL=https://demowebshop.tricentis.com/register", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("NOPCOMMERCE.AUTH=1EA52FC22DCD494FE6725D6BC4F2DF6934B92C917E59C5FD153538ECBC4853F1BC8B20A13FF496D3660D549B7E11BF70207E4AEAE8E7F01596AD5D53323F22E2907224B22167A6396128C5B43D057582226C8E03EB486C7D02BC6C29C699BCD3008CCE12DBFB95EE81DD4FCFD90B4A30D3618D9E6EA45B54917D55177B2BAF2E7C678E0F3AB3AFAEB8C6B5864EB168E2CF9CF79FE1CEF8D5EFE03E7E7532BBA3; DOMAIN=demowebshop.tricentis.com");

	web_submit_data("register", 
		"Action=https://demowebshop.tricentis.com/register", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/register", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=__RequestVerificationToken", "Value=8CrCPiShRJAwOdDTGH_dhI183idPyeSi6-Ns-rnaIYmo1u35O8h_ZmVIQkK9vBaw9JYGSi0yiMic3dM2Fj15tcdo9W0wb5OXFQFj-VSiiUE1", ENDITEM, 
		"Name=Gender", "Value={P_Gender}", ENDITEM, 
		"Name=FirstName", "Value={P_FirstName}", ENDITEM, 
		"Name=LastName", "Value={P_LastName}", ENDITEM, 
		"Name=Email", "Value={P_Email}", ENDITEM, 
		"Name=Password", "Value={P_Password}", ENDITEM, 
		"Name=ConfirmPassword", "Value={P_Password}", ENDITEM, 
		"Name=register-button", "Value=Register", ENDITEM, 
		LAST);

	web_add_cookie("__utmb=78382081.3.10.1790913650; DOMAIN=demowebshop.tricentis.com");

	lr_end_transaction("2_Register",LR_AUTO);

	lr_think_time(8);

	lr_start_transaction("3_continue");

	web_url("Tricentis Demo Web Shop", 
		"URL=https://demowebshop.tricentis.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/registerresult/1", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("3_continue",LR_AUTO);

	lr_start_transaction("4_categories");

	web_url("Computers",
		"URL=https://demowebshop.tricentis.com/{C_category}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://demowebshop.tricentis.com/",
		"Snapshot=t5.inf",
		"Mode=HTML",
		LAST);

	web_add_cookie("__utmb=78382081.5.10.1790913650; DOMAIN=demowebshop.tricentis.com");

	lr_end_transaction("4_categories",LR_AUTO);

	lr_think_time(22);

	lr_start_transaction("5_products");

	web_url("Notebooks",
		"URL=https://demowebshop.tricentis.com/notebooks",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://demowebshop.tricentis.com/{C_category}",
		"Snapshot=t6.inf",
		"Mode=HTML",
		EXTRARES,
		"URL=/content/images/thumbs/0000224_141-inch-laptop_47.png", ENDITEM,
		LAST);

	lr_end_transaction("5_products",LR_AUTO);

	lr_start_transaction("6_Addtocart");

	web_custom_request("1", 
		"URL=https://demowebshop.tricentis.com/addproducttocart/catalog/31/1/1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/notebooks", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	lr_end_transaction("6_Addtocart",LR_AUTO);

	lr_think_time(40);

	lr_start_transaction("7_cart");

	web_url("cart", 
		"URL=https://demowebshop.tricentis.com/cart", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/notebooks", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("7_cart",LR_AUTO);

	lr_start_transaction("8_shipping");

	web_url("getstatesbycountryid", 
		"URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId=41&addEmptyStateIfRequired=true&_=1790913832649", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(5);

	web_submit_data("cart_2", 
		"Action=https://demowebshop.tricentis.com/cart", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=itemquantity7123888", "Value=1", ENDITEM, 
		"Name=discountcouponcode", "Value=", ENDITEM, 
		"Name=giftcardcouponcode", "Value=", ENDITEM, 
		"Name=CountryId", "Value=41", ENDITEM, 
		"Name=StateProvinceId", "Value=0", ENDITEM, 
		"Name=ZipPostalCode", "Value={P_Zip}", ENDITEM, 
		"Name=estimateshipping", "Value=Estimate shipping", ENDITEM, 
		LAST);

	lr_end_transaction("8_shipping",LR_AUTO);

	lr_start_transaction("9_checkout");

	web_add_cookie("__utmb=78382081.8.10.1790913650; DOMAIN=demowebshop.tricentis.com");

	web_submit_data("cart_3", 
		"Action=https://demowebshop.tricentis.com/cart", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=itemquantity7123888", "Value=1", ENDITEM, 
		"Name=discountcouponcode", "Value=", ENDITEM, 
		"Name=giftcardcouponcode", "Value=", ENDITEM, 
		"Name=CountryId", "Value=41", ENDITEM, 
		"Name=StateProvinceId", "Value=0", ENDITEM, 
		"Name=ZipPostalCode", "Value={P_Zip}", ENDITEM, 
		"Name=termsofservice", "Value=on", ENDITEM, 
		"Name=checkout", "Value=checkout", ENDITEM, 
		EXTRARES, 
		"Url=/plugins/Payments.CheckMoneyOrder/logo.jpg", "Referer=https://demowebshop.tricentis.com/onepagecheckout", ENDITEM, 
		"Url=/plugins/Payments.Manual/logo.jpg", "Referer=https://demowebshop.tricentis.com/onepagecheckout", ENDITEM, 
		"Url=/plugins/Payments.PurchaseOrder/logo.jpg", "Referer=https://demowebshop.tricentis.com/onepagecheckout", ENDITEM, 
		"Url=/plugins/Payments.CashOnDelivery/logo.jpg", "Referer=https://demowebshop.tricentis.com/onepagecheckout", ENDITEM, 
		LAST);

	lr_end_transaction("9_checkout",LR_AUTO);

	lr_start_transaction("10_BillinhAddress");

	web_add_cookie("__utmb=78382081.9.10.1790913650; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(24);

	web_url("getstatesbycountryid_2", 
		"URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId=41&addEmptyStateIfRequired=true&_=1790913885314", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(28);

	web_submit_data("OpcSaveBilling", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveBilling/", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=BillingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.FirstName", "Value={P_FirstName}", ENDITEM, 
		"Name=BillingNewAddress.LastName", "Value={P_LastName}", ENDITEM, 
		"Name=BillingNewAddress.Email", "Value={P_Email}", ENDITEM, 
		"Name=BillingNewAddress.Company", "Value=", ENDITEM, 
		"Name=BillingNewAddress.CountryId", "Value=41", ENDITEM, 
		"Name=BillingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.City", "Value={P_City}", ENDITEM, 
		"Name=BillingNewAddress.Address1", "Value={P_Address1}", ENDITEM, 
		"Name=BillingNewAddress.Address2", "Value={P_Address2}", ENDITEM, 
		"Name=BillingNewAddress.ZipPostalCode", "Value={P_Zip}", ENDITEM, 
		"Name=BillingNewAddress.PhoneNumber", "Value={P_phoneNo}", ENDITEM, 
		"Name=BillingNewAddress.FaxNumber", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("10_BillinhAddress",LR_AUTO);

	lr_think_time(12);

	lr_start_transaction("11_shippingaddress");

	web_submit_data("OpcSaveShipping", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShipping/", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=shipping_address_id", "Value=5160749", ENDITEM, 
		"Name=ShippingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.FirstName", "Value={P_FirstName}", ENDITEM, 
		"Name=ShippingNewAddress.LastName", "Value=A", ENDITEM, 
		"Name=ShippingNewAddress.Email", "Value={P_Email}", ENDITEM, 
		"Name=ShippingNewAddress.Company", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.CountryId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.City", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address1", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address2", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.ZipPostalCode", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.PhoneNumber", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.FaxNumber", "Value=", ENDITEM, 
		"Name=PickUpInStore", "Value=false", ENDITEM, 
		LAST);

	lr_end_transaction("11_shippingaddress",LR_AUTO);

	lr_think_time(9);

	lr_start_transaction("12_shipping method");

	web_submit_data("OpcSaveShippingMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShippingMethod/", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=shippingoption", "Value=Ground___Shipping.FixedRate", ENDITEM, 
		LAST);

	lr_end_transaction("12_shipping method",LR_AUTO);

	lr_think_time(7);

	lr_start_transaction("13_paymentmethod");

	web_submit_data("OpcSavePaymentMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSavePaymentMethod/", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=paymentmethod", "Value=Payments.CashOnDelivery", ENDITEM, 
		LAST);

	lr_end_transaction("13_paymentmethod",LR_AUTO);

	lr_think_time(7);

	lr_start_transaction("14_paymentinfo");

	web_custom_request("OpcSavePaymentInfo", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcSavePaymentInfo/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	lr_end_transaction("14_paymentinfo",LR_AUTO);

	lr_start_transaction("15_confirm");

	lr_think_time(12);
	
	web_custom_request("OpcConfirmOrder",
	    "URL=https://demowebshop.tricentis.com/checkout/OpcConfirmOrder/",
	    "Method=POST",
	    "TargetFrame=",
	    "Resource=0",
	    "RecContentType=application/json",
	    "Referer=https://demowebshop.tricentis.com/onepagecheckout",
	    "Mode=HTML",
	    LAST);
	
	web_url("completed",
	    "URL=https://demowebshop.tricentis.com/checkout/completed/",
	    "TargetFrame=",
	    "Resource=0",
	    "RecContentType=text/html",
	    "Referer=https://demowebshop.tricentis.com/onepagecheckout",
	    "Mode=HTML",
	    LAST);
	
	lr_end_transaction("15_confirm", LR_AUTO);

	return 0;
}
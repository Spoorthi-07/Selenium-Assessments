Action()
{
    lr_start_transaction("1_LaunchUrl");

    web_set_sockets_option("SSL_VERSION", "AUTO");

    web_add_auto_header("Accept-Language",
        "en-US,en;q=0.9");

    /* Correlation - C_category */
    web_reg_save_param_regexp(
        "ParamName=C_category",
        "RegExp=categories/(.*?)\">",
        SEARCH_FILTERS,
        "Scope=Body",
        "IgnoreRedirections=No",
        "RequestUrl=*/jpetstore.aspectran.com/*",
        LAST);

    web_url("jpetstore.aspectran.com",
        "URL=https://jpetstore.aspectran.com/",
        "TargetFrame=",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=",
        "Snapshot=t1.inf",
        "Mode=HTML",
        LAST);

    lr_end_transaction("1_LaunchUrl", LR_AUTO);

    lr_think_time(6);

    lr_start_transaction("2_Register");

    web_url("Sign Up",
        "URL=https://jpetstore.aspectran.com/account/newAccountForm",
        "TargetFrame=",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://jpetstore.aspectran.com/",
        "Snapshot=t2.inf",
        "Mode=HTML",
        LAST);

    lr_think_time(11);

    web_submit_data("newAccount",
        "Action=https://jpetstore.aspectran.com/account/newAccount",
        "Method=POST",
        "EncodeAtSign=YES",
        "TargetFrame=",
        "RecContentType=text/html",
        "Referer=https://jpetstore.aspectran.com/account/newAccountForm",
        "Snapshot=t3.inf",
        "Mode=HTML",
        ITEMDATA,
        "Name=username", "Value={Username}", ENDITEM,
        "Name=password", "Value={Password}", ENDITEM,
        "Name=repeatedPassword", "Value={Password}", ENDITEM,
        "Name=firstName", "Value={FirstName}", ENDITEM,
        "Name=lastName", "Value={LastName}", ENDITEM,
        "Name=email", "Value={Email}", ENDITEM,
        "Name=phone", "Value={PhoneNo}", ENDITEM,
        "Name=address1", "Value={Address1}", ENDITEM,
        "Name=address2", "Value={Address2}", ENDITEM,
        "Name=city", "Value={City}", ENDITEM,
        "Name=state", "Value={State}", ENDITEM,
        "Name=zip", "Value={Zip}", ENDITEM,
        "Name=country", "Value={Country}", ENDITEM,
        "Name=languagePreference", "Value=english", ENDITEM,
        "Name=favouriteCategoryId", "Value={C_category}", ENDITEM,
        LAST);

    lr_end_transaction("2_Register", LR_AUTO);

    lr_start_transaction("3_Login");

    web_submit_data("signon",
        "Action=https://jpetstore.aspectran.com/account/signon",
        "Method=POST",
        "TargetFrame=",
        "RecContentType=text/html",
        "Referer=https://jpetstore.aspectran.com/account/signonForm?created=true",
        "Snapshot=t5.inf",
        "Mode=HTML",
        ITEMDATA,
        "Name=referer", "Value=", ENDITEM,
        "Name=username", "Value={Username}", ENDITEM,
        "Name=password", "Value={Password}", ENDITEM,
        LAST);

    lr_end_transaction("3_Login", LR_AUTO);

    lr_think_time(6);

    lr_start_transaction("4_Category");

    /*
     * IMPORTANT:
     * C_product is captured from the Category response.
     * Therefore correlation MUST be placed before this request.
     */
    web_reg_save_param_regexp(
        "ParamName=C_product",
        "RegExp=products/(.*?)\">",
        SEARCH_FILTERS,
        "Scope=Body",
        "IgnoreRedirections=No",
        "RequestUrl=*/jpetstore.aspectran.com/*",
        LAST);

    web_url("Fish",
        "URL=https://jpetstore.aspectran.com/categories/{C_category}",
        "TargetFrame=",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://jpetstore.aspectran.com/",
        "Snapshot=t6.inf",
        "Mode=HTML",
        LAST);

    lr_end_transaction("4_Category", LR_AUTO);

    lr_think_time(24);

    lr_start_transaction("5_product");

    /*
     * C_Item is captured from Product page.
     * Example:
     * href="/products/FI-SW-01/items/EST-1"
     */
    web_reg_save_param_regexp(
        "ParamName=C_Item",
        "RegExp=items/(.*?)\">",
        SEARCH_FILTERS,
        "Scope=Body",
        "IgnoreRedirections=No",
        "RequestUrl=*/jpetstore.aspectran.com/*",
        LAST);

    web_url("FI-SW-01",
        "URL=https://jpetstore.aspectran.com/products/{C_product}",
        "TargetFrame=",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://jpetstore.aspectran.com/categories/{C_category}",
        "Snapshot=t7.inf",
        "Mode=HTML",
        LAST);

    lr_end_transaction("5_product", LR_AUTO);

    lr_think_time(7);

    lr_start_transaction("6_item");

    web_url("EST-1",
        "URL=https://jpetstore.aspectran.com/products/{C_product}/items/{C_Item}",
        "TargetFrame=",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://jpetstore.aspectran.com/products/{C_product}",
        "Snapshot=t8.inf",
        "Mode=HTML",
        LAST);

    lr_end_transaction("6_item", LR_AUTO);

    lr_start_transaction("7_Addtocart");

    web_url("Add to Cart",
        "URL=https://jpetstore.aspectran.com/cart/addItemToCart?itemId={C_Item}",
        "TargetFrame=",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://jpetstore.aspectran.com/products/{C_product}/items/{C_Item}",
        "Snapshot=t9.inf",
        "Mode=HTML",
        LAST);

    lr_end_transaction("7_Addtocart", LR_AUTO);

    lr_think_time(18);

    lr_start_transaction("8_checkout");

    web_url("Proceed to Checkout",
        "URL=https://jpetstore.aspectran.com/order/newOrderForm",
        "TargetFrame=",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://jpetstore.aspectran.com/cart/viewCart",
        "Snapshot=t10.inf",
        "Mode=HTML",
        LAST);

    lr_end_transaction("8_checkout", LR_AUTO);

    lr_think_time(14);

    lr_start_transaction("9_continue");

    web_submit_data("newOrder",
        "Action=https://jpetstore.aspectran.com/order/newOrder",
        "Method=POST",
        "TargetFrame=",
        "RecContentType=text/html",
        "Referer=https://jpetstore.aspectran.com/order/newOrderForm",
        "Snapshot=t11.inf",
        "Mode=HTML",
        ITEMDATA,
        "Name=paymentForm", "Value=true", ENDITEM,
        "Name=billingForm", "Value=true", ENDITEM,
        "Name=cardType", "Value=Visa", ENDITEM,
        "Name=creditCard", "Value={P_creditcard}", ENDITEM,
        "Name=expiryDate", "Value=12/2019", ENDITEM,
        "Name=billToFirstName", "Value={FirstName}", ENDITEM,
        "Name=billToLastName", "Value=m", ENDITEM,
        "Name=billAddress1", "Value={Address1}", ENDITEM,
        "Name=billAddress2", "Value={Address2}", ENDITEM,
        "Name=billCity", "Value={City}", ENDITEM,
        "Name=billState", "Value={State}", ENDITEM,
        "Name=billZip", "Value={Zip}", ENDITEM,
        "Name=billCountry", "Value={Country}", ENDITEM,
        LAST);

    lr_end_transaction("9_continue", LR_AUTO);

    lr_start_transaction("10_confirm");

    web_submit_data("submitOrder",
        "Action=https://jpetstore.aspectran.com/order/submitOrder",
        "Method=POST",
        "TargetFrame=",
        "RecContentType=text/html",
        "Referer=https://jpetstore.aspectran.com/order/newOrder",
        "Snapshot=t12.inf",
        "Mode=HTML",
        ITEMDATA,
        "Name=confirmed", "Value=true", ENDITEM,
        LAST);

    lr_end_transaction("10_confirm", LR_AUTO);

    return 0;
}
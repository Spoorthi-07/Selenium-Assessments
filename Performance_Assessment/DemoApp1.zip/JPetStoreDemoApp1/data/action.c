Action()
{

	lr_start_transaction("1_LaunchUrl");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_url("jpetstore.aspectran.com", 
		"URL=https://jpetstore.aspectran.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("1_LaunchUrl",LR_AUTO);

	lr_think_time(6);

	lr_start_transaction("2_Register");

	web_url("Sign Up", 
		"URL=https://jpetstore.aspectran.com/account/newAccountForm", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(11);

	web_submit_data("newAccount", 
		"Action=https://jpetstore.aspectran.com/account/newAccount", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/account/newAccountForm", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=username", "Value=john", ENDITEM, 
		"Name=password", "Value=john123", ENDITEM, 
		"Name=repeatedPassword", "Value=john123", ENDITEM, 
		"Name=firstName", "Value=john", ENDITEM, 
		"Name=lastName", "Value=m", ENDITEM, 
		"Name=email", "Value=john@gmail.com", ENDITEM, 
		"Name=phone", "Value=9874563215", ENDITEM, 
		"Name=address1", "Value=mg", ENDITEM, 
		"Name=address2", "Value=kp", ENDITEM, 
		"Name=city", "Value=bal", ENDITEM, 
		"Name=state", "Value=kar", ENDITEM, 
		"Name=zip", "Value=584133", ENDITEM, 
		"Name=country", "Value=ind", ENDITEM, 
		"Name=languagePreference", "Value=english", ENDITEM, 
		"Name=favouriteCategoryId", "Value=FISH", ENDITEM, 
		LAST);

	web_submit_data("newAccount_2", 
		"Action=https://jpetstore.aspectran.com/account/newAccount", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/account/newAccount", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=username", "Value=johnn", ENDITEM, 
		"Name=password", "Value=john123", ENDITEM, 
		"Name=repeatedPassword", "Value=john123", ENDITEM, 
		"Name=firstName", "Value=john", ENDITEM, 
		"Name=lastName", "Value=m", ENDITEM, 
		"Name=email", "Value=john@gmail.com", ENDITEM, 
		"Name=phone", "Value=9874563215", ENDITEM, 
		"Name=address1", "Value=mg", ENDITEM, 
		"Name=address2", "Value=kp", ENDITEM, 
		"Name=city", "Value=bal", ENDITEM, 
		"Name=state", "Value=kar", ENDITEM, 
		"Name=zip", "Value=584133", ENDITEM, 
		"Name=country", "Value=ind", ENDITEM, 
		"Name=languagePreference", "Value=english", ENDITEM, 
		"Name=favouriteCategoryId", "Value=FISH", ENDITEM, 
		LAST);

	lr_end_transaction("2_Register",LR_AUTO);

	lr_start_transaction("3_Login");

	web_submit_data("signon", 
		"Action=https://jpetstore.aspectran.com/account/signon", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/account/signonForm?created=true", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=referer", "Value=", ENDITEM, 
		"Name=username", "Value=johnn", ENDITEM, 
		"Name=password", "Value=john123", ENDITEM, 
		LAST);

	lr_end_transaction("3_Login",LR_AUTO);

	lr_think_time(6);

	lr_start_transaction("4_Category");

	web_url("Fish", 
		"URL=https://jpetstore.aspectran.com/categories/FISH", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("4_Category",LR_AUTO);

	lr_think_time(24);

	lr_start_transaction("1_transaction");

	lr_start_transaction("5_product");

	web_url("FI-SW-01", 
		"URL=https://jpetstore.aspectran.com/products/FI-SW-01", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/categories/FISH", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("5_product",LR_AUTO);

	lr_think_time(7);

	lr_start_transaction("6_item");

	web_url("EST-1", 
		"URL=https://jpetstore.aspectran.com/products/FI-SW-01/items/EST-1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/products/FI-SW-01", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("6_item",LR_AUTO);

	lr_start_transaction("7_Addtocart");

	web_url("Add to Cart", 
		"URL=https://jpetstore.aspectran.com/cart/addItemToCart?itemId=EST-1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/products/FI-SW-01/items/EST-1", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("7_Addtocart",LR_AUTO);

	lr_think_time(18);

	lr_start_transaction("8_checkout");

	web_url("Proceed to Checkout", 
		"URL=https://jpetstore.aspectran.com/order/newOrderForm", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/cart/viewCart", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("8_checkout",LR_AUTO);

	lr_think_time(14);

	lr_start_transaction("9_continue");

	web_submit_data("newOrder", 
		"Action=https://jpetstore.aspectran.com/order/newOrder", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=paymentForm", "Value=true", ENDITEM, 
		"Name=billingForm", "Value=true", ENDITEM, 
		"Name=cardType", "Value=Visa", ENDITEM, 
		"Name=creditCard", "Value=999999999999999", ENDITEM, 
		"Name=expiryDate", "Value=12/2019", ENDITEM, 
		"Name=billToFirstName", "Value=john", ENDITEM, 
		"Name=billToLastName", "Value=m", ENDITEM, 
		"Name=billAddress1", "Value=mg", ENDITEM, 
		"Name=billAddress2", "Value=kp", ENDITEM, 
		"Name=billCity", "Value=bal", ENDITEM, 
		"Name=billState", "Value=kar", ENDITEM, 
		"Name=billZip", "Value=584133", ENDITEM, 
		"Name=billCountry", "Value=ind", ENDITEM, 
		LAST);

	lr_end_transaction("9_continue",LR_AUTO);

	lr_start_transaction("10_confirm");

	web_submit_data("submitOrder", 
		"Action=https://jpetstore.aspectran.com/order/submitOrder", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrder", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=confirmed", "Value=true", ENDITEM, 
		LAST);

	return 0;
}